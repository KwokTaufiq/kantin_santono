<footer class="site-footer">
  <div class="container">
    <p>&copy; {{ date('Y') }} Kantin Santono. All rights reserved.</p>
  </div>
</footer>