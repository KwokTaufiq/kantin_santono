<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kantin Santono</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"/>
</head>
<body>

  <?php echo $__env->make('pesan.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->make('pesan.coversection', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <section class="menu-section">
    <div class="menu-container">
      <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
          <div class="card--image">
            <img src="<?php echo e(asset('gambar-menu/' . $menu->gambar)); ?>" alt="<?php echo e($menu->nama_menu); ?>">
          </div>
          <div class="card--detail">
            <h3 class="card--title"><?php echo e($menu->nama_menu); ?></h3>
            <p class="price">Rp<?php echo e(number_format($menu->harga, 0, ',', '.')); ?></p>
            <button class="add-to-cart" 
                    data-id="<?php echo e($menu->id); ?>"
                    data-nama="<?php echo e($menu->nama_menu); ?>"
                    data-harga="<?php echo e($menu->harga); ?>">
              Tambah
            </button>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '<?php echo e(session('success')); ?>',
            timer: 3000,
            showConfirmButton: false
        });
    </script>
<?php endif; ?>


  <?php echo $__env->make('pesan.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <script src="<?php echo e(asset('build/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\kantin-santono\resources\views/pesan/index.blade.php ENDPATH**/ ?>