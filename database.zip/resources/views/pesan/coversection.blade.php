<section class="cover">
  <div class="cover--overlay">
      <h1>Kantin Santono</h1>
      <span class="slogan">Harga pas, Hati puas</span>
  </div>
</section>