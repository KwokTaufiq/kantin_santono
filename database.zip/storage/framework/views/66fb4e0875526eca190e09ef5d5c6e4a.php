<footer class="site-footer">
  <div class="container">
    <p>&copy; <?php echo e(date('Y')); ?> Kantin Santono. All rights reserved.</p>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\kantin-santono\resources\views/pesan/footer.blade.php ENDPATH**/ ?>